# Requirements and verification

All limits are illustrative assumptions. Numerical passes apply to the selected reduced-model design.

| ID | Requirement | Allocation | Evidence | Status |
|---|---|---|---|---|
| R01 | The modeled system scope ends at monitoring and operator review. | SYS | T-BOUNDARY | checked in descriptive model |
| R02 | Unhealthy observation input shall produce Degraded status and block the mock alert. | SUP | V-FAULT | passed in mock logic |
| R03 | An unreviewed mock observation shall not produce an alert. | SUP | V-REVIEW | passed in mock logic |
| R04 | Maximum support temperature shall satisfy <= 65 C for the selected demonstrator design. | PHY | T-TEMP | passed for selected reduced-model design |
| R05 | Tip deflection shall satisfy <= 0.5 mm for the selected demonstrator design. | PHY | T-DEFLECTION | passed for selected reduced-model design |
| R06 | First natural frequency shall satisfy >= 22 Hz for the selected demonstrator design. | PHY | T-FREQUENCY | passed for selected reduced-model design |
| R07 | Root bending stress shall satisfy <= 40 MPa for the selected demonstrator design. | PHY | T-STRESS | passed for selected reduced-model design |
| R08 | Support reach shall satisfy >= 0.16 m for the selected demonstrator design. | PHY | T-REACH | passed for selected reduced-model design |
| R09 | The surrogate prediction wrapper shall reject input outside its declared design domain. | SYS | T-DOMAIN | passed in numerical workflow |
| R10 | Observation records shall contain a source timestamp, sensor-health flag, and confidence between 0 and 1. | OBS | T-OBS-CONTRACT | specified; no real observation integration test |
| R11 | Physical acceptance shall require independent measurements of temperatures and structural response. | PHY | T-PHYSICAL | pending physical validation |
