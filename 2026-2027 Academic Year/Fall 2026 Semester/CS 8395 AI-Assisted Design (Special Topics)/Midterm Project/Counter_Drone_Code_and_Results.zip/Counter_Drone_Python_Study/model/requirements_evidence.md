# Midterm requirement-to-evidence matrix

| ID | Owner | Verification | Result | Evidence |
|---|---|---|---|---|
| R01 | SYS | T-BOUNDARY | descriptive boundary review | model/system_model.json, model/architecture.mmd |
| R02 | SUP | V-FAULT | passed in mock logic | src/physics.py, results/verification.json |
| R03 | SUP | V-REVIEW | passed in mock logic | src/physics.py, results/verification.json |
| R04 | PHY | T-TEMP | numerically satisfied at selected design | results/summary.json, results/confirmed_designs.json, config.json |
| R05 | PHY | T-DEFLECTION | numerically satisfied at selected design | results/summary.json, results/confirmed_designs.json, config.json |
| R06 | PHY | T-FREQUENCY | numerically satisfied at selected design | results/summary.json, results/confirmed_designs.json, config.json |
| R07 | PHY | T-STRESS | numerically satisfied at selected design | results/summary.json, results/confirmed_designs.json, config.json |
| R08 | PHY | T-REACH | numerically satisfied at selected design | results/summary.json, results/confirmed_designs.json, config.json |
| R09 | SYS | T-DOMAIN | recorded domain-guard check passed | run_study.py, results/summary.json |
| R10 | OBS | T-OBS-CONTRACT | specified; integration verification pending | model/system_model.json |
| R11 | PHY | T-PHYSICAL | physical validation pending |  |
