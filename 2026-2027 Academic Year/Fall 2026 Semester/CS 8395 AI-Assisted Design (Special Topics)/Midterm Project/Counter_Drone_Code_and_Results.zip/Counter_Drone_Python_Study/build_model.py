"""Create a descriptive, machine-readable system baseline and its trace links."""
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
CFG=json.loads((ROOT/"config.json").read_text())
S=json.loads((ROOT/"results/summary.json").read_text())
OUT=ROOT/"model";OUT.mkdir(exist_ok=True)
LIM=CFG["limits"]
COMP=[
 {"id":"SYS","name":"Monitoring-system demonstrator","role":"System boundary and linked requirements","implementation":"descriptive baseline"},
 {"id":"OBS","name":"Observation source","role":"Provide timestamped observations and sensor health","implementation":"specified; real sensing not implemented"},
 {"id":"EST","name":"Estimation and confidence","role":"Describe object state and uncertainty","implementation":"specified; real perception not implemented"},
 {"id":"SUP","name":"Supervisor","role":"Expose health and gate a mock alert on review","implementation":"mock guard logic implemented"},
 {"id":"UI","name":"Operator console","role":"Display evidence and collect review input","implementation":"specified; UI not implemented"},
 {"id":"PHY","name":"Generic instrument support","role":"Thermal and structural benchmark","implementation":"reduced numerical models implemented"},
 {"id":"COM","name":"Computing electronics","role":"Supply assumed heat load to physical model","implementation":"8 W heat-load assumption; software/power hardware not implemented"},
 {"id":"HUM","name":"Operator","role":"Review observations and make an external response decision","implementation":"external actor; mock boolean review input"},
]
REQ=[]
def req(i,statement,owner,test,status,source,value=None):
    REQ.append({"id":i,"statement":statement,"allocated_to":owner,"verified_by":test,
                "status":status,"course_source":source,"acceptance":value})
req("R01","The modeled system scope ends at monitoring and operator review.","SYS","T-BOUNDARY","checked in descriptive model","L02 p.12; L03 p.13")
req("R02","Unhealthy observation input shall produce Degraded status and block the mock alert.","SUP","V-FAULT","passed in mock logic","L03 p.22; L07 pp.13-15")
req("R03","An unreviewed mock observation shall not produce an alert.","SUP","V-REVIEW","passed in mock logic","L03 pp.18-22")
for i,text,key,owner,test,unit,op,source in [
 ("R04","Maximum support temperature", "max_temperature_C","PHY","T-TEMP","C","<=","L08 p.15"),
 ("R05","Tip deflection","max_deflection_mm","PHY","T-DEFLECTION","mm","<=","L08 pp.3,9"),
 ("R06","First natural frequency","minimum_frequency_Hz","PHY","T-FREQUENCY","Hz",">=","L08 p.14"),
 ("R07","Root bending stress","max_stress_MPa","PHY","T-STRESS","MPa","<=","L08 p.9"),
 ("R08","Support reach","minimum_reach_m","PHY","T-REACH","m",">=","L03 p.10; L06 p.21")]:
    req(i,f"{text} shall satisfy {op} {LIM[key]} {unit} for the selected demonstrator design.",owner,test,
        "passed for selected reduced-model design",source,{"operator":op,"value":LIM[key],"unit":unit,"config_key":key})
req("R09","The surrogate prediction wrapper shall reject input outside its declared design domain.","SYS","T-DOMAIN","passed in numerical workflow","L07 pp.23-25; L09 p.27",CFG["design_variables"])
req("R10","Observation records shall contain a source timestamp, sensor-health flag, and confidence between 0 and 1.","OBS","T-OBS-CONTRACT","specified; no real observation integration test","L04 p.17; L05 p.24")
req("R11","Physical acceptance shall require independent measurements of temperatures and structural response.","PHY","T-PHYSICAL","pending physical validation","L07 pp.23-25")

INTERFACES=[
 {"id":"I01","from":"OBS","to":"EST","kind":"data","fields":{"source_timestamp_s":"s","sensor_healthy":"boolean","confidence":"unit interval"}},
 {"id":"I02","from":"EST","to":"SUP","kind":"data","fields":{"observation_available":"boolean","confidence":"unit interval"}},
 {"id":"I03","from":"SUP","to":"UI","kind":"data","fields":{"mode":"Monitor/Confirm/Alert/Degraded","alert":"boolean","health":"string"}},
 {"id":"I04","from":"HUM","to":"SUP","kind":"review","fields":{"reviewed":"boolean mock input"}},
 {"id":"I05","from":"COM","to":"PHY","kind":"thermal","fields":{"tip_heat_W":"W"}},
 {"id":"I06","from":"PHY","to":"OBS","kind":"structural","fields":{"mount_interface":"descriptive rigid attachment"}},
]
TESTS=[{"id":r["verified_by"],"requirement":r["id"],"status":r["status"]} for r in REQ]
state_rules=[
 {"priority":1,"guard":"not sensor_healthy","mode":"Degraded","alert":False},
 {"priority":2,"guard":"sensor_healthy and not observation_available","mode":"Monitor","alert":False},
 {"priority":3,"guard":"sensor_healthy and observation_available and not reviewed","mode":"Confirm","alert":False},
 {"priority":4,"guard":"sensor_healthy and observation_available and reviewed","mode":"Alert","alert":True},
]
MODEL={"schema_version":"1.0","name":"Counter-drone monitoring course demonstrator",
 "model_language":"plain JSON descriptive model; not a claimed SysML conformance export",
 "scope":"Generic monitoring architecture plus an offline instrument-support benchmark. No operational detection, tracking, response hardware, or end-to-end integrated system.",
 "components":COMP,"interfaces":INTERFACES,"requirements":REQ,"verification_cases":TESTS,
 "supervisory_decision_rules":state_rules,
 "behavior_note":"The implemented supervisor is stateless mock guard logic. This is not a time-domain hybrid simulation or a persistent deployed state machine.",
 "physics":{"equations":"steady 1D fin thermal FE; Euler-Bernoulli static and modal FE","coupling":"one-way temperature-to-modulus; no thermoelastic expansion feedback","parameters":"../config.json"},
 "numerical_evidence":{"summary":"../results/summary.json","verification":"../results/verification.json","selected_design":S["surrogate_choice"]}}

ids={c["id"] for c in COMP}; tests={t["id"] for t in TESTS}
assert len(ids)==len(COMP)
assert len({r["id"] for r in REQ})==len(REQ)
assert all(r["allocated_to"] in ids and r["verified_by"] in tests for r in REQ)
assert all(i["from"] in ids and i["to"] in ids for i in INTERFACES)
assert S["out_of_domain_prediction_rejected"]
assert all(i["kind"] in {"data","review","thermal","structural"} for i in INTERFACES)
(OUT/"system_model.json").write_text(json.dumps(MODEL,indent=2)+"\n")
(OUT/"traceability.md").write_text("# Requirements and verification\n\nAll limits are illustrative assumptions. Numerical passes apply to the selected reduced-model design.\n\n| ID | Requirement | Allocation | Evidence | Status |\n|---|---|---|---|---|\n"+
    "\n".join(f"| {r['id']} | {r['statement']} | {r['allocated_to']} | {r['verified_by']} | {r['status']} |" for r in REQ)+"\n")
(OUT/"architecture.mmd").write_text('''flowchart TD
  OBS["Observation source: specified"] --> EST["Estimation and confidence: specified"]
  EST --> SUP["Supervisor: mock guard logic"]
  SUP --> UI["Operator console: specified"]
  HUM["Operator: external actor"] -->|review input| SUP
  COM["Computing: assumed heat load"] -->|thermal load| PHY["Instrument support: numerical models"]
  PHY -->|descriptive mounting interface| OBS
''')
(OUT/"behavior.mmd").write_text('''flowchart TD
  IN["Mock observation inputs"] --> HEALTH{"Sensor healthy?"}
  HEALTH -->|no| DEG["Degraded: block alert"]
  HEALTH -->|yes| OBS{"Observation available?"}
  OBS -->|no| MON["Monitor"]
  OBS -->|yes| REV{"Human reviewed?"}
  REV -->|no| CON["Confirm: block alert"]
  REV -->|yes| ALT["Alert"]
''')
audit={"passed":True,"components":len(COMP),"interfaces":len(INTERFACES),"requirements":len(REQ),
       "requirements_with_allocation_and_test":len(REQ),
       "pending_requirements":[r["id"] for r in REQ if r["status"].startswith(("specified","pending"))],
       "claim_boundary":"References, allocations, and port kinds are checked. This is not SysML syntax validation or physical-system validation."}
(OUT/"model_audit.json").write_text(json.dumps(audit,indent=2)+"\n")
print(json.dumps(audit,indent=2))
