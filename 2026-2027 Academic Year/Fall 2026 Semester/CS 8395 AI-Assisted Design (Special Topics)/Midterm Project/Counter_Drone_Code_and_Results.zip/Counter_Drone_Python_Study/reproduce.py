"""Reproduce the Python numerical study and model artifacts only."""
import subprocess
import sys
from pathlib import Path
root = Path(__file__).resolve().parent
for script in ['run_study.py', 'build_model.py', 'build_midterm_artifacts.py']:
    subprocess.run([sys.executable, str(root / script)], cwd=root, check=True)
