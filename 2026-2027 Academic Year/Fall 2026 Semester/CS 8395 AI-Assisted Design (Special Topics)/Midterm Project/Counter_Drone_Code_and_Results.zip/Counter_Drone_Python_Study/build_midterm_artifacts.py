"""Generate intermediate MBSE evidence from the current model and recorded results."""
import json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'src'))
from physics import supervise

def main():
    model=json.loads((ROOT/'model/system_model.json').read_text())
    config=json.loads((ROOT/'config.json').read_text())
    results=json.loads((ROOT/'results/summary.json').read_text())
    chosen=results['surrogate_choice']; limits=config['limits']
    numeric={
      'R04':('max_temperature_C','max_temperature_C','<=','C'),
      'R05':('tip_deflection_mm','max_deflection_mm','<=','mm'),
      'R06':('first_frequency_Hz','minimum_frequency_Hz','>=','Hz'),
      'R07':('root_stress_MPa','max_stress_MPa','<=','MPa'),
      'R08':('length_m','minimum_reach_m','>=','m')}
    evidence=[]
    for r in model['requirements']:
        row={**r,'artifact':'A04','evidence_files':[],'observed':None,'result':'pending'}
        if r['id'] in numeric:
            key,limit,op,unit=numeric[r['id']]
            passed=chosen[key]<=limits[limit] if op=='<=' else chosen[key]>=limits[limit]
            assert passed,r['id']
            row.update(result='numerically satisfied at selected design',observed=chosen[key],unit=unit,
              evidence_files=['results/summary.json','results/confirmed_designs.json','config.json'],
              model_equation={'R04':'P01','R05':'P03','R06':'P04','R07':'P05','R08':'P06'}[r['id']])
        elif r['id']=='R02':
            observation=supervise(False,True,True)
            assert observation['mode']=='Degraded' and not observation['alert']
            row.update(result='passed in mock logic',observed=observation,evidence_files=['src/physics.py','results/verification.json'])
        elif r['id']=='R03':
            observation=supervise(True,True,False)
            assert observation['mode']=='Confirm' and not observation['alert']
            row.update(result='passed in mock logic',observed=observation,evidence_files=['src/physics.py','results/verification.json'])
        elif r['id']=='R09':
            assert results['out_of_domain_prediction_rejected']
            row.update(result='recorded domain-guard check passed',observed=True,
              evidence_files=['run_study.py','results/summary.json'])
        elif r['id']=='R01':
            row.update(result='descriptive boundary review',evidence_files=['model/system_model.json','model/architecture.mmd'])
        elif r['id']=='R10':
            row.update(result='specified; integration verification pending',evidence_files=['model/system_model.json'])
        else:
            row.update(result='physical validation pending',evidence_files=[])
        evidence.append(row)
    params=[
      {'id':'P01','name':'Thermal field','relation':"(k A theta')' - h p theta = 0; theta(0)=0; k A theta'(L)=Q",'inputs':['length_m','thickness_m','width_m','conductivity_W_mK','convection_W_m2K','tip_heat_W','ambient_C'],'outputs':['max_temperature_C','theta_K'],'implementation':'src/physics.py:thermal','requirements':['R04']},
      {'id':'P02','name':'Temperature-to-modulus coupling','relation':'E(x) = E0 [1 - beta theta(x)]','inputs':['theta_K','E0_Pa','modulus_temperature_slope_per_K'],'outputs':['element_modulus_Pa'],'implementation':'src/physics.py:beam','requirements':['R05','R06'],'assumption':'Uncalibrated one-way relation; thermal expansion omitted'},
      {'id':'P03','name':'Static response','relation':'K(T) u = F','inputs':['geometry','element_modulus_Pa','payload_kg','self_weight'],'outputs':['tip_deflection_mm'],'implementation':'src/physics.py:beam','requirements':['R05']},
      {'id':'P04','name':'First natural frequency','relation':'K(T) phi = omega^2 M phi; f1 = omega1/(2 pi)','inputs':['geometry','element_modulus_Pa','payload_kg','density_kg_m3'],'outputs':['first_frequency_Hz'],'implementation':'src/physics.py:beam','requirements':['R06']},
      {'id':'P05','name':'Root bending stress','relation':'sigma = (P L + q L^2/2) t/(2 I)','inputs':['geometry','payload_kg','density_kg_m3'],'outputs':['root_stress_MPa'],'implementation':'src/physics.py:beam','requirements':['R07']},
      {'id':'P06','name':'Geometry and objective','relation':'A = b t; I = b t^3/12; mass = rho b t L; L >= L_min','inputs':['length_m','thickness_m','width_m','density_kg_m3'],'outputs':['support_mass_kg','reach_feasible'],'implementation':'src/physics.py:beam; src/physics.py:feasible','requirements':['R08']}]
    inventory=[
      {'id':'A01','artifact':'System scope and context','report_section':'I','source':'model/system_model.json','status':'documented'},
      {'id':'A02','artifact':'Block/interface architecture','report_section':'II-A','source':'model/architecture.mmd; model/system_model.json','status':'documented and rendered'},
      {'id':'A03','artifact':'Supervisory activity / guard model','report_section':'II-B','source':'model/behavior.mmd; src/physics.py:supervise','status':'rendered; mock logic checked'},
      {'id':'A04','artifact':'Requirements-to-evidence traceability','report_section':'II-C; Table I','source':'model/requirements_evidence.json','status':'11 linked requirements; pending tests retained'},
      {'id':'A05','artifact':'Parametric and analysis dependencies','report_section':'III','source':'model/parametric_relations.json; src/physics.py','status':'documented and executable reduced models'},
      {'id':'A06','artifact':'Numerical verification','report_section':'IV; Table III','source':'results/verification.json','status':'11 recorded numerical / mock-logic checks passed'},
      {'id':'A07','artifact':'Constrained physical-subsystem trade study','report_section':'V-B; Table IV','source':'results/candidate_designs.json; results/summary.json','status':'512 candidates evaluated'},
      {'id':'A08','artifact':'Surrogate comparison supporting analysis automation','report_section':'V-C; Table V','source':'results/summary.json; results/held_out_predictions.json','status':'recorded held-out results'}]
    cases=[]
    for healthy,available,reviewed in [(False,True,True),(True,False,False),(True,True,False),(True,True,True)]:
        cases.append({'inputs':{'sensor_healthy':healthy,'observation_available':available,'reviewed':reviewed},'output':supervise(healthy,available,reviewed)})
    outputs={'requirements_evidence.json':evidence,'parametric_relations.json':params,
       'artifact_inventory.json':inventory,'mock_behavior_cases.json':cases}
    for filename,data in outputs.items():(ROOT/'model'/filename).write_text(json.dumps(data,indent=2)+'\n')
    (ROOT/'model/requirements_evidence.md').write_text('# Midterm requirement-to-evidence matrix\n\n'+
       '| ID | Owner | Verification | Result | Evidence |\n|---|---|---|---|---|\n'+
       '\n'.join(f"| {r['id']} | {r['allocated_to']} | {r['verified_by']} | {r['result']} | {', '.join(r['evidence_files'])} |" for r in evidence)+'\n')
    model['midterm_artifacts']={'inventory':'artifact_inventory.json','requirement_evidence':'requirements_evidence.json',
       'parametric_relations':'parametric_relations.json','behavior_examples':'mock_behavior_cases.json',
       'report':'../reports/Counter_Drone_Midterm_Report.pdf'}
    (ROOT/'model/system_model.json').write_text(json.dumps(model,indent=2)+'\n')
    print('Midterm artifacts built: 8 indexed artifacts, 11 requirement-evidence links, 6 parametric relations.')

if __name__=='__main__':main()
