"""Reduced-order, generic instrument-support benchmark. All units are SI."""
import numpy as np
from scipy.linalg import solve, eigh

DEFAULTS = {
    "width_m": 0.04, "E0_Pa": 69e9, "density_kg_m3": 2700.0,
    "conductivity_W_mK": 167.0, "convection_W_m2K": 12.0,
    "ambient_C": 25.0, "tip_heat_W": 8.0, "payload_kg": 0.25,
    "modulus_temperature_slope_per_K": 0.0004, "gravity_m_s2": 9.80665,
    "elements": 24,
}

def thermal(length, thickness, config=None, elements=None):
    c = DEFAULTS | (config or {})
    n = int(elements or c["elements"])
    if length <= 0 or thickness <= 0 or n < 2:
        raise ValueError("Positive dimensions and at least two elements are required")
    b, k, h = c["width_m"], c["conductivity_W_mK"], c["convection_W_m2K"]
    if min(b, k, h) <= 0 or c["tip_heat_W"] < 0:
        raise ValueError("Invalid thermal material, convection, or heat input")
    A, perimeter, le = b * thickness, 2 * (b + thickness), length / n
    ke = k*A/le*np.array([[1., -1.], [-1., 1.]])
    ke += h*perimeter*le/6*np.array([[2., 1.], [1., 2.]])
    K = np.zeros((n+1, n+1))
    for e in range(n):
        K[e:e+2, e:e+2] += ke
    F = np.zeros(n+1)
    F[-1] = c["tip_heat_W"]
    theta = np.zeros(n+1)
    theta[1:] = solve(K[1:, 1:], F[1:], assume_a="pos")
    convection = h*perimeter*np.trapezoid(theta, dx=le)
    clamp_heat = -(K @ theta - F)[0]
    return {"theta_K": theta, "x_m": np.linspace(0, length, n+1),
            "max_temperature_C": c["ambient_C"] + float(theta[-1]),
            "energy_residual_W": float(c["tip_heat_W"]-convection-clamp_heat)}

def thermal_analytic_tip_rise(length, thickness, config=None):
    c = DEFAULTS | (config or {})
    A = c["width_m"]*thickness
    perimeter = 2*(c["width_m"]+thickness)
    m = np.sqrt(c["convection_W_m2K"]*perimeter/(c["conductivity_W_mK"]*A))
    return c["tip_heat_W"]*np.tanh(m*length)/(c["conductivity_W_mK"]*A*m)

def beam(length, thickness, config=None, elements=None, theta_K=None):
    c = DEFAULTS | (config or {})
    n = int(elements or c["elements"])
    if length <= 0 or thickness <= 0 or n < 2:
        raise ValueError("Invalid beam dimensions or discretization")
    b, rho, le = c["width_m"], c["density_kg_m3"], length/n
    A, I = b*thickness, b*thickness**3/12
    if theta_K is None:
        theta_K = np.zeros(n+1)
    if len(theta_K) != n+1:
        raise ValueError("Thermal and structural meshes must share nodes")
    q = rho*A*c["gravity_m_s2"]
    nd = 2*(n+1)
    K, M, F = np.zeros((nd, nd)), np.zeros((nd, nd)), np.zeros(nd)
    kpattern = np.array([[12,6*le,-12,6*le],[6*le,4*le**2,-6*le,2*le**2],
                         [-12,-6*le,12,-6*le],[6*le,2*le**2,-6*le,4*le**2]])
    mpattern = np.array([[156,22*le,54,-13*le],[22*le,4*le**2,13*le,-3*le**2],
                         [54,13*le,156,-22*le],[-13*le,-3*le**2,-22*le,4*le**2]])
    for e in range(n):
        d = np.arange(2*e, 2*e+4)
        theta_mid = (theta_K[e]+theta_K[e+1])/2
        E = c["E0_Pa"]*(1-c["modulus_temperature_slope_per_K"]*theta_mid)
        if E <= 0:
            raise ValueError("Temperature-dependent modulus is outside its model domain")
        K[np.ix_(d,d)] += E*I/le**3*kpattern
        M[np.ix_(d,d)] += rho*A*le/420*mpattern
        F[d] += q*le/12*np.array([6, le, 6, -le])
    tip_dof = 2*n
    F[tip_dof] += c["payload_kg"]*c["gravity_m_s2"]
    M[tip_dof, tip_dof] += c["payload_kg"]
    free = np.arange(2, nd)
    Kr, Mr = K[np.ix_(free,free)], M[np.ix_(free,free)]
    u = solve(Kr, F[free], assume_a="pos")
    eig = eigh(Kr, Mr, subset_by_index=[0,0], eigvals_only=True)[0]
    root_moment = c["payload_kg"]*c["gravity_m_s2"]*length+q*length**2/2
    return {"tip_deflection_mm": float(u[tip_dof-2]*1000),
            "first_frequency_Hz": float(np.sqrt(eig)/(2*np.pi)),
            "root_stress_MPa": float(root_moment*thickness/(2*I)/1e6),
            "support_mass_kg": float(rho*A*length)}

def evaluate(x, config=None, elements=None):
    length, thickness = map(float, x)
    th = thermal(length, thickness, config, elements)
    st = beam(length, thickness, config, elements, th["theta_K"])
    return {"length_m": length, "thickness_m": thickness,
            "max_temperature_C": th["max_temperature_C"], **st,
            "energy_residual_W": th["energy_residual_W"]}

def feasible(records, limits):
    return np.array([r["length_m"] >= limits["minimum_reach_m"] and
                     r["max_temperature_C"] <= limits["max_temperature_C"] and
                     r["tip_deflection_mm"] <= limits["max_deflection_mm"] and
                     r["first_frequency_Hz"] >= limits["minimum_frequency_Hz"] and
                     r["root_stress_MPa"] <= limits["max_stress_MPa"]
                     for r in records], dtype=bool)

def supervise(sensor_healthy=True, observation_available=False, reviewed=False):
    """Mock supervisory logic only. No real object detection or tracking."""
    if not sensor_healthy:
        return {"mode":"Degraded", "alert":False, "health":"sensor unavailable"}
    if not observation_available:
        return {"mode":"Monitor", "alert":False, "health":"healthy"}
    if not reviewed:
        return {"mode":"Confirm", "alert":False, "health":"healthy"}
    return {"mode":"Alert", "alert":True, "health":"healthy"}
