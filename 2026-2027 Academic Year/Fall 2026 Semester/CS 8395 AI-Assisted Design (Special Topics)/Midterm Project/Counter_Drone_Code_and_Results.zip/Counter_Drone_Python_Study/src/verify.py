"""Independent analytical and conservation checks, plus interface-logic tests."""
import numpy as np
from scipy.optimize import brentq
from physics import DEFAULTS, thermal, thermal_analytic_tip_rise, beam, evaluate, supervise

def verify(config=None):
    results=[]
    def check(name, actual, bound, description):
        passed=bool(actual<=bound)
        results.append({"test":name,"actual":float(actual),"acceptance_bound":bound,
                        "passed":passed,"description":description})
        if not passed:
            raise AssertionError(f"{name}: {actual} exceeds {bound}")
    L,t=.18,.004
    physical=DEFAULTS | (config or {})
    th=thermal(L,t,physical,elements=24)
    analytic=thermal_analytic_tip_rise(L,t,physical)
    check("V-THERMAL-ANALYTIC",abs(th["theta_K"][-1]/analytic-1),.002,
          "Thermal FE tip rise versus exact constant-property fin solution, relative error")
    check("V-ENERGY",abs(th["energy_residual_W"]),1e-8,
          "Input heat equals convection plus clamp heat conduction, residual in W")
    c=physical | {"modulus_temperature_slope_per_K":0.0}
    st=beam(L,t,c,elements=24)
    A=c["width_m"]*t; I=c["width_m"]*t**3/12; E=c["E0_Pa"]
    q=c["density_kg_m3"]*A*c["gravity_m_s2"]
    P=c["payload_kg"]*c["gravity_m_s2"]
    exact=(P*L**3/(3*E*I)+q*L**4/(8*E*I))*1000
    check("V-STATIC-ANALYTIC",abs(st["tip_deflection_mm"]/exact-1),1e-6,
          "Beam FE deflection versus independent tip-load and self-weight formula")
    cbare=c | {"payload_kg":0.0}
    beta=brentq(lambda z:np.cosh(z)*np.cos(z)+1,1.,2.)
    fexact=beta**2/(2*np.pi*L**2)*np.sqrt(E*I/(c["density_kg_m3"]*A))
    fn=beam(L,t,cbare,elements=24)["first_frequency_Hz"]
    check("V-MODE-ANALYTIC",abs(fn/fexact-1),.001,
          "Unloaded cantilever first mode versus analytical characteristic root")
    mesh=[{"elements":n,**evaluate([L,t],physical,elements=n)} for n in [8,16,24,32,64]]
    for key,tol in [("max_temperature_C",.002),("tip_deflection_mm",.002),("first_frequency_Hz",.002)]:
        check("V-MESH-"+key,abs(mesh[2][key]/mesh[-1][key]-1),tol,
              "24-element result versus 64-element reference at representative design")
    out=supervise(False,True,True)
    check("V-FAULT",0 if out["mode"]=="Degraded" and not out["alert"] else 1,0,
          "Missing sensor health blocks the mock alert and exposes Degraded mode")
    check("V-REVIEW",0 if not supervise(True,True,False)["alert"] else 1,0,
          "An unreviewed mock observation cannot emit an alert")
    check("V-MODE-SEQUENCE",0 if [supervise()["mode"],supervise(True,True)["mode"],
          supervise(True,True,True)["mode"]]==["Monitor","Confirm","Alert"] else 1,0,
          "Healthy mock inputs exercise Monitor, Confirm, and Alert")
    rejected=False
    try:evaluate([0,t])
    except ValueError:rejected=True
    check("V-DIMENSIONS",0 if rejected else 1,0,"Nonpositive support dimensions are rejected")
    return {"checks":results,"mesh_study":mesh,"passed":all(r["passed"] for r in results)}
