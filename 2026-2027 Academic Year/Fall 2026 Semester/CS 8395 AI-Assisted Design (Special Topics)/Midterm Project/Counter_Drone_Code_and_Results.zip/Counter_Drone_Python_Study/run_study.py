#!/usr/bin/env python3
"""Reproduce numerical verification, benchmark data, model records, and plots."""
import os
for _name in ["OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","MKL_NUM_THREADS"]:
    os.environ[_name]="1"
import sys, json, time, warnings, platform
from pathlib import Path
import numpy as np
import scipy, sklearn
from scipy.stats import qmc
from scipy.interpolate import RBFInterpolator
from scipy.optimize import minimize
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import Ridge
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import ConstantKernel, RBF
from sklearn.exceptions import ConvergenceWarning
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/"src"))
from physics import evaluate, feasible, DEFAULTS
from verify import verify

OUT=ROOT/"results"; OUT.mkdir(exist_ok=True)
FIG=OUT/"figures"; FIG.mkdir(exist_ok=True)
CFG=json.loads((ROOT/"config.json").read_text())
EXP,PHY,LIM=CFG["experiment"],CFG["physics"],CFG["limits"]
LOW=np.array(CFG["design_variables"]["lower"]); HIGH=np.array(CFG["design_variables"]["upper"])
TARGETS=["max_temperature_C","tip_deflection_mm","first_frequency_Hz"]

def write(name,obj):
    (OUT/name).write_text(json.dumps(obj,indent=2,allow_nan=False)+"\n")

def sample(n,seed):
    return qmc.scale(qmc.LatinHypercube(d=2,seed=seed).random(n),LOW,HIGH)

def normalized(X):return (np.asarray(X)-LOW)/(HIGH-LOW)
def physics_batch(X):return [evaluate(row,PHY) for row in X]
def targets(records):return np.array([[r[k] for k in TARGETS] for r in records])
def positive_targets(records):
    Y=targets(records);Y[:,0]-=PHY["ambient_C"];return Y
def unpack(logy):
    Y=np.exp(logy);Y[:,0]+=PHY["ambient_C"];return Y

def bounded_gp_optimizer(objective, initial_theta, bounds):
    result=minimize(lambda theta:objective(theta,eval_gradient=False),initial_theta,
        method="Powell",bounds=bounds,options={"maxiter":200,"xtol":1e-4,"ftol":1e-7})
    if not result.success:
        raise RuntimeError("GP kernel optimizer failed: "+str(result.message))
    return result.x,result.fun

def new_gp():
    return GaussianProcessRegressor(kernel=ConstantKernel(1.,(1e-3,1e3))*RBF([.5,.5],(1e-2,1e2)),
        alpha=EXP["gp_alpha"],normalize_y=True,optimizer=bounded_gp_optimizer,
        n_restarts_optimizer=EXP["gp_optimizer_restarts"],random_state=101)

def fit_gp(X,R):
    gp=new_gp()
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always",ConvergenceWarning)
        gp.fit(normalized(X),np.log(positive_targets(R)))
    return gp,[str(w.message) for w in caught]

def guarded_gp(gp,X):
    X=np.asarray(X)
    if np.any(X<LOW) or np.any(X>HIGH):
        raise ValueError("Predictor rejects designs outside the declared training domain")
    mu,std=gp.predict(normalized(X),return_std=True)
    return unpack(mu),unpack(mu-EXP["gp_credible_interval_z"]*std),unpack(mu+EXP["gp_credible_interval_z"]*std)

def classify(X,Y):
    # Exact geometric and static stress checks are inexpensive and do not use the expensive oracle.
    b=PHY["width_m"]; L=X[:,0];t=X[:,1];A=b*t;I=b*t**3/12
    q=PHY["density_kg_m3"]*A*PHY["gravity_m_s2"]
    stress=(PHY["payload_kg"]*PHY["gravity_m_s2"]*L+q*L**2/2)*t/(2*I)/1e6
    return ((L>=LIM["minimum_reach_m"])&(Y[:,0]<=LIM["max_temperature_C"])&
            (Y[:,1]<=LIM["max_deflection_mm"])&(Y[:,2]>=LIM["minimum_frequency_Hz"])&
            (stress<=LIM["max_stress_MPa"]))

def safest_mask(X,lower,upper):
    Y=upper.copy();Y[:,2]=lower[:,2];return classify(X,Y)

def best_record(records,mask=None):
    if mask is None:mask=feasible(records,LIM)
    good=[r for r,m in zip(records,mask) if m]
    return min(good,key=lambda r:r["support_mass_kg"]) if good else None

def surrogate_workflow(Xtrain,Xcandidate):
    # Baseline candidate truth is intentionally not an argument to this function.
    start=time.perf_counter();t0=start
    Rtrain=physics_batch(Xtrain);train_sim_s=time.perf_counter()-t0
    t0=time.perf_counter();gp,warn=fit_gp(Xtrain,Rtrain);fit_s=time.perf_counter()-t0
    t0=time.perf_counter();yp,yl,yu=guarded_gp(gp,Xcandidate)
    safe=safest_mask(Xcandidate,yl,yu)
    mass=PHY["density_kg_m3"]*PHY["width_m"]*Xcandidate[:,0]*Xcandidate[:,1]
    idx=np.flatnonzero(safe)
    idx=idx[np.argsort(mass[idx])][:EXP["confirmation_budget"]]
    pred_s=time.perf_counter()-t0
    t0=time.perf_counter();confirmed=physics_batch(Xcandidate[idx]);confirm_s=time.perf_counter()-t0
    total=time.perf_counter()-start
    return {"gp":gp,"train":Rtrain,"indices":idx,"confirmed":confirmed,"prediction":yp,
            "lower":yl,"upper":yu,"safe":safe,"chosen":best_record(confirmed),
            "warnings":warn,"timing":{"total_s":total,"train_simulation_s":train_sim_s,
            "fit_s":fit_s,"prediction_and_selection_s":pred_s,"confirmation_s":confirm_s}}

def errors(Y,P,truthmask,predmask):
    detail=[]
    for j,key in enumerate(TARGETS):
        d=P[:,j]-Y[:,j]
        detail.append({"target":key,"rmse":float(np.sqrt(np.mean(d*d))),
            "mae":float(np.mean(abs(d))),"max_abs_error":float(max(abs(d))),
            "range_normalized_rmse_pct":float(np.sqrt(np.mean(d*d))/np.ptp(Y[:,j])*100)})
    return {"by_target":detail,"false_feasible":int(np.sum(predmask&~truthmask)),
            "false_infeasible":int(np.sum(~predmask&truthmask)),
            "correct_classification_pct":float(np.mean(predmask==truthmask)*100)}

def plot_style():
    plt.rcParams.update({"font.family":"DejaVu Sans","font.size":10,"axes.spines.top":False,
        "axes.spines.right":False,"axes.labelcolor":"#173244","text.color":"#173244",
        "axes.titlesize":12,"figure.facecolor":"white","axes.grid":True,"grid.alpha":.18})

def plots(Rcandidate,chosen_baseline,chosen_surrogate,Rtest,predictions,workflow,mesh):
    plot_style(); X=np.array([[r["length_m"],r["thickness_m"]] for r in Rcandidate]);
    ok=feasible(Rcandidate,LIM);mass=np.array([r["support_mass_kg"]*1000 for r in Rcandidate])
    fig,ax=plt.subplots(figsize=(7.4,4.4))
    ax.scatter(X[~ok,0]*1000,X[~ok,1]*1000,c="#CAD3D8",s=14,label="Infeasible in model")
    sc=ax.scatter(X[ok,0]*1000,X[ok,1]*1000,c=mass[ok],cmap="viridis",s=19,label="Feasible in model")
    fig.colorbar(sc,ax=ax,label="Support mass (g)")
    for rec,color,label in [(chosen_baseline,"#B75F1C","Simulation-only choice"),(chosen_surrogate,"#142C44","Surrogate-confirmed choice")]:
        if rec:ax.scatter(rec["length_m"]*1000,rec["thickness_m"]*1000,marker="*",s=180,
            edgecolor="white",color=color,label=label,zorder=5)
    ax.set(xlabel="Support length (mm)",ylabel="Support thickness (mm)",title="Candidate design space: reduced-model feasibility")
    ax.legend(loc="upper left",fontsize=8);fig.tight_layout();fig.savefig(FIG/"trade_space.png",dpi=180);plt.close(fig)
    Y=targets(Rtest)
    fig,axs=plt.subplots(1,3,figsize=(10.5,3.5))
    labels=["Maximum temperature (C)","Tip deflection (mm)","First frequency (Hz)"]
    for j,ax in enumerate(axs):
        for name,P in predictions.items():ax.scatter(Y[:,j],P[:,j],s=10,alpha=.6,label=name)
        mn,mx=Y[:,j].min(),Y[:,j].max();ax.plot([mn,mx],[mn,mx],color="#172D41",lw=1)
        ax.set(xlabel="Physics model",ylabel="Surrogate",title=labels[j])
    axs[0].legend(fontsize=7);fig.tight_layout();fig.savefig(FIG/"held_out_predictions.png",dpi=180);plt.close(fig)
    Xslice=np.column_stack([np.full(100,.18),np.linspace(LOW[1],HIGH[1],100)])
    Rslice=physics_batch(Xslice);Ys=targets(Rslice);mean,lower,upper=guarded_gp(workflow["gp"],Xslice)
    fig,ax=plt.subplots(figsize=(7.4,3.6));ax.plot(Xslice[:,1]*1000,Ys[:,0],label="Reduced physics model",color="#172D41")
    ax.plot(Xslice[:,1]*1000,mean[:,0],label="GP prediction",color="#168388",ls="--")
    ax.fill_between(Xslice[:,1]*1000,lower[:,0],upper[:,0],color="#168388",alpha=.22,label="Nominal 95% GP interval")
    ax.axhline(LIM["max_temperature_C"],color="#B75F1C",ls=":",label="Illustrative thermal limit")
    ax.set(xlabel="Thickness (mm), fixed length = 180 mm",ylabel="Maximum temperature (C)",title="GP uncertainty slice inside the declared domain")
    ax.legend(fontsize=8);fig.tight_layout();fig.savefig(FIG/"gp_interval.png",dpi=180);plt.close(fig)
    fig,axs=plt.subplots(1,3,figsize=(10.5,3.1))
    for key,ax in zip(TARGETS,axs):
        vals=np.array([r[key] for r in mesh]);err=np.maximum(abs(vals[:-1]/vals[-1]-1)*100,1e-8)
        ax.loglog([r["elements"] for r in mesh[:-1]],err,"o-",color="#168388")
        ax.set(xlabel="Elements",ylabel="Difference vs 64 elements (%)",title=key.replace("_"," "))
    fig.tight_layout();fig.savefig(FIG/"mesh_convergence.png",dpi=180);plt.close(fig)

def main():
    verification=verify(PHY);write("verification.json",verification)
    print("Analytical, energy, mesh and supervisory checks passed",flush=True)
    splits={k:sample(EXP[k+"_n"],EXP["seeds"][k]) for k in ["train","validation","test","candidate"]}
    # Exact non-overlap check: held-out points are not reused as training points.
    for a,b in [("train","validation"),("train","test"),("validation","test")]:
        assert not ({tuple(x) for x in splits[a]} & {tuple(x) for x in splits[b]})
    trials=[];Rcandidate=None; workflow=None
    evaluate([.18,.004],PHY) # warm up imports/solver paths, outside workflow counts
    for i in range(EXP["timing_repeats"]):
        t0=time.perf_counter();Rcandidate=physics_batch(splits["candidate"]);base_s=time.perf_counter()-t0
        workflow=surrogate_workflow(splits["train"],splits["candidate"])
        trials.append({"trial":i+1,"baseline_total_s":base_s,"surrogate":workflow["timing"]})
        print(f"Timing trial {i+1}: baseline {base_s:.3f}s, surrogate {workflow['timing']['total_s']:.3f}s",flush=True)
    baseline=best_record(Rcandidate);chosen=workflow["chosen"]
    if baseline is None or chosen is None:raise RuntimeError("No feasible design found with the declared limits")
    Rval=physics_batch(splits["validation"]);Rtest=physics_batch(splits["test"])
    logy=np.log(positive_targets(workflow["train"]))
    poly=make_pipeline(PolynomialFeatures(2),Ridge(alpha=1e-8)).fit(normalized(splits["train"]),logy)
    rbf=RBFInterpolator(normalized(splits["train"]),logy,kernel="thin_plate_spline",smoothing=1e-8)
    metrics={};predtest={}
    for split,R in [("validation",Rval),("test",Rtest)]:
        X=splits[split];Y=targets(R);tm=feasible(R,LIM)
        predictions={"Quadratic":unpack(poly.predict(normalized(X))),
                     "RBF":unpack(rbf(normalized(X))),"GP":guarded_gp(workflow["gp"],X)[0]}
        metrics[split]={k:errors(Y,P,tm,classify(X,P)) for k,P in predictions.items()}
        if split=="test":predtest=predictions
    Yt=targets(Rtest);mt,lt,ut=guarded_gp(workflow["gp"],splits["test"])
    coverage=((Yt>=lt)&(Yt<=ut)).mean(axis=0)*100
    safe=safest_mask(splits["test"],lt,ut);tm=feasible(Rtest,LIM)
    gp_safety={"nominal_interval_pct":95,"empirical_interval_coverage_pct":dict(zip(TARGETS,map(float,coverage))),
        "interval_screen_false_feasible":int(np.sum(safe&~tm)),
        "interval_screen_false_infeasible":int(np.sum(~safe&tm)),
        "interval_screen_accepted":int(sum(safe)),"true_test_feasible":int(sum(tm))}
    base_seconds=float(np.median([t["baseline_total_s"] for t in trials]))
    sur_seconds=float(np.median([t["surrogate"]["total_s"] for t in trials]))
    confirmation_n=len(workflow["indices"]);calls=EXP["train_n"]+confirmation_n
    overhead=float(np.median([t["surrogate"]["fit_s"]+t["surrogate"]["prediction_and_selection_s"] for t in trials]))
    summary={"status":"simulation study; no physical validation", "baseline_choice":baseline,
        "surrogate_choice":chosen,"mass_gap_pct":(chosen["support_mass_kg"]/baseline["support_mass_kg"]-1)*100,
        "baseline_physics_calls_per_workflow":EXP["candidate_n"],"surrogate_physics_calls_per_workflow":calls,
        "training_calls":EXP["train_n"],"confirmation_calls":confirmation_n,
        "physics_call_reduction_pct":(1-calls/EXP["candidate_n"])*100,
        "candidate_n":EXP["candidate_n"],"actual_feasible_candidates":int(sum(feasible(Rcandidate,LIM))),
        "gp_interval_screen_candidates":int(sum(workflow["safe"])),
        "confirmed_constraint_violations":int(sum(~feasible(workflow["confirmed"],LIM))),
        "median_baseline_seconds":base_seconds,"median_surrogate_seconds":sur_seconds,
        "observed_baseline_to_surrogate_wall_ratio":base_seconds/sur_seconds,
        "estimated_break_even_physics_call_seconds":overhead/(EXP["candidate_n"]-calls),
        "timing_trials":trials,"metrics":metrics,"gp_safety":gp_safety,
        "gp_kernel":str(workflow["gp"].kernel_),"gp_fit_warnings":workflow["warnings"],
        "optimizer":"Bounded Powell, checked for successful termination, using training likelihood only",
        "final_test_protocol":"Pilot seed 33 informed development. A training-only line-search diagnostic prompted changing the optimizer. Seed 55 is the fresh final held-out split, evaluated after this change. No tuning follows the final test.",
        "verification_check_count":len(verification["checks"]),
        "accounting":"Workflow counts include training and confirmation. Validation, held-out audit, convergence checks, warm-up, and plotting evaluations are additional offline study costs. Timings include each workflow's actual simulation, fitting, prediction, and confirmation. Three trials use the same predefined designs.",
        "versions":{"python":platform.python_version(),"numpy":np.__version__,"scipy":scipy.__version__,"scikit_learn":sklearn.__version__,"matplotlib":matplotlib.__version__}}
    try:guarded_gp(workflow["gp"],np.array([[LOW[0]-.01,LOW[1]]]))
    except ValueError:summary["out_of_domain_prediction_rejected"]=True
    else:raise AssertionError("Out-of-domain guard failed")
    write("summary.json",summary)
    write("candidate_designs.json",Rcandidate)
    write("training_designs.json",workflow["train"])
    write("validation_designs.json",Rval)
    write("held_out_designs.json",Rtest)
    write("held_out_predictions.json",[{"design":r,"predictions":{k:dict(zip(TARGETS,map(float,P[i]))) for k,P in predtest.items()},
        "gp_lower":dict(zip(TARGETS,map(float,lt[i]))),"gp_upper":dict(zip(TARGETS,map(float,ut[i])))} for i,r in enumerate(Rtest)])
    write("confirmed_designs.json",workflow["confirmed"])
    plots(Rcandidate,baseline,chosen,Rtest,predtest,workflow,verification["mesh_study"])
    print(json.dumps({k:v for k,v in summary.items() if k in ["mass_gap_pct","physics_call_reduction_pct","median_baseline_seconds","median_surrogate_seconds","gp_safety"]},indent=2),flush=True)

if __name__=="__main__":main()
