# Source and provenance record

All experiment inputs in `config.json` are demonstrator assumptions. They are not specifications for existing equipment, certified material properties, experimental observations, or supplier prices. The results JSON files contain simulations produced by the included code. The objective is support mass, an early design proxy, rather than a measured whole-platform cost.

## Supplied course lectures

- L01 - Intro v2(3).pdf: CPS examples and integration, pp. 4-7 and 13-15. Surrogates and physics guidance, pp. 23-24.
- L02_MBSE_1_L01_Part(2).pdf: the C-UAS project example, p. 12. Unified model and systems-model pillars, pp. 23, 28 and 31.
- L03_MBSE_2_with_v2.pdf: diagram meanings, p. 6. Traceable requirements, p. 10. System context, structure, interfaces and behavior, pp. 13-22. Digital thread, p. 28.
- L04_Arch_Modeling.pdf: project option, p. 5. Composition and design-analysis flow, pp. 17-19.
- L05_L04_Arch_Modeling_2.pdf: architecture languages and multi-domain integration, pp. 7, 9 and 12-16. Interfaces and well-formedness, pp. 24-25.
- L06_DSE.pdf: variables/domains/constraints and constrained exploration, pp. 8-10 and 21. Model-guided search, p. 39.
- L07_Dynamics_Modeling.pdf: hybrid models, pp. 13-15. Model fidelity, verification versus validation, and uncertainty, pp. 20 and 23-25.
- L08_Higher_Fidelity_Analysis.pdf: physical analysis and derived requirements, pp. 3-6. Structural, modal and thermal analysis, pp. 9 and 14-15. ML and automation limits, pp. 21-22.
- L09_MDAO.pdf: integrated disciplinary evaluation and consistency, pp. 10-18. Surrogate optimization and its limitations, pp. 24-27.

These PDFs are already supplied by the user and are not duplicated in this package. Page numbers above refer to PDF pages.

## External primary sources checked for this work

- David M. Parks, MIT 2.002 Mechanics and Materials II, *Euler-Bernoulli Beams: Bending, Buckling, and Vibration*, February 9, 2004. Beam equilibrium and boundary conditions, PDF pp. 7-9. Vibration governing equations, PDF pp. 14-16. https://www.ocw.mit.edu/courses/2-002-mechanics-and-materials-ii-spring-2004/bc25a56b5a91ad29ca5c7419616686f7_lec2.pdf
- SciPy 1.17.0 reference, `scipy.stats.qmc.LatinHypercube`: stratified sampling and rescaling. https://docs.scipy.org/doc/scipy-1.17.0/reference/generated/scipy.stats.qmc.LatinHypercube.html
- scikit-learn 1.8.0 reference, `GaussianProcessRegressor`: kernel fitting, normalization, multiple targets and predictive standard deviation. https://scikit-learn.org/1.8/modules/generated/sklearn.gaussian_process.GaussianProcessRegressor.html
- SciPy 1.17.0 reference, `minimize(method='Powell')`: bounded optimization and success/termination diagnostics. https://docs.scipy.org/doc/scipy-1.17.0/reference/optimize.minimize-powell.html

The heat-conduction weak form, assembled element matrices, thermal-to-modulus assumption, domain guards, objective and benchmark protocol are explicitly defined in the included code and report. The analytic thermal expression follows from the specified constant-coefficient boundary-value problem. It is a numerical verification reference, not external experimental validation.
