# Python Study and Results

This package contains only the numerical study, model records, analysis figures, and results. Paper source and report compilation are in the separate Paper and Report package. No LaTeX installation is needed here.

## Run

Use Python 3.12. Open a terminal in this folder and run:

```text
python -m venv .venv
```

Windows PowerShell:

```text
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe reproduce.py
```

macOS/Linux:

```text
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python reproduce.py
```

Or, in an already activated environment:

```text
python -m pip install -r requirements.txt
python reproduce.py
```

## Contents

- run_study.py: verification, sampling, surrogate fitting, workflow comparisons, and figures.
- src/: physical model and independent verification.
- config.json: assumed physical inputs, limits, seeds, and budgets.
- build_model.py and build_midterm_artifacts.py: architecture, requirements, traceability, and evidence records.
- model/: structured models, editable diagrams, and supporting rendered views.
- results/: recorded designs, predictions, verification, summary metrics, and figures.
- SOURCES.md: course and primary references.

reproduce.py runs the three Python stages; it does not compile a paper. Existing results are included, so they can be inspected before rerunning. Timing measurements vary by machine. The study uses assumed inputs and reduced numerical models; physical validation and sensing integration remain pending. Report pointers in the model records refer to the companion paper package.
